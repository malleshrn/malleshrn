//
//  MapFramework.h
//  MapFramework
//
//  Created by Patel, Hitesh on 10/26/16.
//  Copyright © 2016 SAP. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for MapFramework.
FOUNDATION_EXPORT double MapFrameworkVersionNumber;

//! Project version string for MapFramework.
FOUNDATION_EXPORT const unsigned char MapFrameworkVersionString[];
